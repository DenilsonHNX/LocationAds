package ao.co.isptec.aplm.locationads.network.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.*;

public class UserProfile implements Serializable {

    @SerializedName("username")
    private String username;

    @SerializedName("properties")
    private Map<String, String> properties;

    @SerializedName("lastUpdated")
    private long lastUpdated;

    public UserProfile() {
        this.properties = new HashMap<>();
        this.lastUpdated = System.currentTimeMillis();
    }

    public UserProfile(String username) {
        this.username = username;
        this.properties = new HashMap<>();
        this.lastUpdated = System.currentTimeMillis();
    }

    // Adicionar propriedade
    public boolean addProperty(String key, String value) {
        if (key == null || key.trim().isEmpty() || value == null || value.trim().isEmpty()) {
            return false;
        }
        properties.put(key.trim(), value.trim());
        this.lastUpdated = System.currentTimeMillis();
        return true;
    }

    // Remover propriedade
    public boolean removeProperty(String key) {
        if (properties.containsKey(key)) {
            properties.remove(key);
            this.lastUpdated = System.currentTimeMillis();
            return true;
        }
        return false;
    }

    // Verificar se corresponde a uma restrição
    public boolean matchesRestriction(String key, String value) {
        String profileValue = properties.get(key);
        return profileValue != null && profileValue.equalsIgnoreCase(value);
    }

    // Verificar se corresponde a qualquer restrição da lista
    public boolean matchesAnyRestriction(List<PerfilKeyValue> restrictions) {
        for (PerfilKeyValue restriction : restrictions) {
            if (matchesRestriction(restriction.getKey(), restriction.getValue())) {
                return true;
            }
        }
        return false;
    }

    // Obter todas as chaves
    public Set<String> getAllKeys() {
        return new HashSet<>(properties.keySet());
    }

    // Obter todas as propriedades como lista
    public List<PerfilKeyValue> getAllPropertiesAsList() {
        List<PerfilKeyValue> list = new ArrayList<>();
        for (Map.Entry<String, String> entry : properties.entrySet()) {
            list.add(new PerfilKeyValue(entry.getKey(), entry.getValue()));
        }
        return list;
    }

    public String getPropertyValue(String key) {
        return properties.get(key);
    }

    public int getPropertyCount() {
        return properties.size();
    }

    public void clearAllProperties() {
        properties.clear();
        this.lastUpdated = System.currentTimeMillis();
    }

    // Getters e Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

    public long getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    // ==================== MÉTODOS NOVOS ADICIONADOS ====================
    // ✅ Compatibilidade com sistema de políticas

    /**
     * Obtém o perfil como Map<String, Object> para compatibilidade
     * com o sistema de políticas
     */
    public Map<String, Object> getProfile() {
        // Converter Map<String, String> para Map<String, Object>
        Map<String, Object> profile = new HashMap<>();
        if (properties != null) {
            profile.putAll(properties);
        }
        return profile;
    }

    /**
     * Define o perfil a partir de Map<String, Object>
     * Converte para o formato interno Map<String, String>
     */
    public void setProfile(Map<String, Object> profile) {
        if (profile == null) {
            this.properties = new HashMap<>();
            return;
        }

        // Converter Map<String, Object> para Map<String, String>
        this.properties = new HashMap<>();
        for (Map.Entry<String, Object> entry : profile.entrySet()) {
            if (entry.getValue() != null) {
                this.properties.put(entry.getKey(), entry.getValue().toString());
            }
        }
        this.lastUpdated = System.currentTimeMillis();
    }

    /**
     * Adiciona propriedade aceitando Object como valor
     */
    public void addProfileProperty(String key, Object value) {
        if (key != null && value != null) {
            addProperty(key, value.toString());
        }
    }

    /**
     * Remove propriedade do perfil (alias para removeProperty)
     */
    public void removeProfileProperty(String key) {
        removeProperty(key);
    }

    /**
     * Obtém propriedade do perfil como Object
     */
    public Object getProfileProperty(String key) {
        return getPropertyValue(key);
    }

    /**
     * Verifica se tem propriedade no perfil
     */
    public boolean hasProfileProperty(String key) {
        return properties != null && properties.containsKey(key);
    }

    /**
     * Limpa o perfil (alias para clearAllProperties)
     */
    public void clearProfile() {
        clearAllProperties();
    }
}